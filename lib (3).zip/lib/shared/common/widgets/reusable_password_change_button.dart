import 'package:flutter/material.dart';
import 'package:schoolerp/core/common/widgets/custom_confirm_button.dart';

class ReusablePasswordActionButtons extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Expanded(
                child: CustomConfirmButton(
              label: 'Save Password',
              onPressed: () {},
            )),
          ],
        ),
      ),
    );
  }
}
